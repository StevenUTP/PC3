import React, { useState, useEffect } from "react";
import { Embarcacion } from "../Embarcacion";

interface EmbarcacionFormProps {
    onSubmit: (embarcacion: Omit<Embarcacion, 'id'>) => void;
    initialData?: Embarcacion;
    onCancel?: () => void;
}

const EmbarcacionForm: React.FC<EmbarcacionFormProps> = ({ onSubmit, initialData, onCancel }) => {
    const [nombre, setNombre] = useState(initialData?.nombre || '');
    const [capacidad, setCapacidad] = useState(initialData?.capacidad || 0);
    const [descripcion, setDescripcion] = useState(initialData?.descripcion || '');
    const [fechaProgramada, setFechaProgramada] = useState(() => {
        if (!initialData?.fechaProgramada) return '';
        
        const date = initialData.fechaProgramada instanceof Date 
            ? initialData.fechaProgramada 
            : new Date(initialData.fechaProgramada);
            
        return date.toISOString().substring(0, 10);
    });

    useEffect(() => {
        if (initialData) {
            setNombre(initialData.nombre);
            setCapacidad(initialData.capacidad);
            setDescripcion(initialData.descripcion || '');
            
            if (initialData.fechaProgramada) {
                const date = initialData.fechaProgramada instanceof Date 
                    ? initialData.fechaProgramada 
                    : new Date(initialData.fechaProgramada);
                setFechaProgramada(date.toISOString().substring(0, 10));
            } else {
                setFechaProgramada('');
            }
        }
    }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (!nombre || capacidad <= 0 || !descripcion || !fechaProgramada) {
            alert("Por favor, completa todos los campos correctamente.");
            return;
        }

        onSubmit({ nombre, capacidad, descripcion, fechaProgramada: new Date(fechaProgramada) });

        if (!initialData) {
            setNombre('');
            setCapacidad(0);
            setDescripcion('');
            setFechaProgramada('');
        }
    };
    

    return (
        <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
            <h2>{initialData ? 'Editar Embarcación' : 'Crear Embarcación'}</h2>
            <input
                type="text"
                placeholder="Nombre"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                required
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            <input
                type="number"
                placeholder="Capacidad"
                value={capacidad.toString()}
                onChange={(e) => setCapacidad(Number(e.target.value))}
                required
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            <input
                type="text"
                placeholder="Descripción"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                style={{ marginBottom: '10px', marginRight: '10px' }}
                required
            />
            <input
                type="date"
                placeholder="Fecha Programada"
                value={fechaProgramada}
                onChange={(e) => setFechaProgramada(e.target.value)}
                style={{ marginBottom: '10px', marginRight: '10px' }}
                required
            />
            <button type="submit">
                {initialData ? 'Actualizar' : 'Crear'}
            </button>
            {initialData && onCancel && (
                <button
                    type="button"
                    onClick={onCancel}
                    style={{ marginLeft: '10px' }}
                >
                    Cancelar
                </button>
            )}
        </form>
    );
};

export default EmbarcacionForm;

// En EmbarcacionTable.tsx
