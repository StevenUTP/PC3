
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import EmbarcacionTable from './components/EmbarcacionTable';
import EmbarcacionForm from './components/EmbarcacionForm';
import { Embarcacion } from './Embarcacion';

const App: React.FC = () => {
  const [embarcaciones, setEmbarcaciones] = useState<Embarcacion[]>([]);
  const [editingEmbarcacion, setEditingEmbarcacion] = useState<Embarcacion | null>(null);

  useEffect(() => {
    fetchEmbarcaciones();
  }, []);

  const fetchEmbarcaciones = async () => {
    try {
      const response = await axios.get('/api/embarcaciones');
      setEmbarcaciones(response.data);
    } catch (error) {
      console.error('Error fetching embarcaciones:', error);
    }
  };

  const handleCreate = async (embarcacion: Omit<Embarcacion, 'id'>) => {
    try {
      const response = await axios.post('/api/embarcaciones', embarcacion);
      setEmbarcaciones([...embarcaciones, response.data]);
    } catch (error) {
      console.error('Error creating embarcacion:', error);
    }
  };

  const handleEdit = (embarcacion: Embarcacion) => {
    setEditingEmbarcacion(embarcacion);
  };

  const handleUpdate = async (embarcacion: Omit<Embarcacion, 'id'>) => {
    if (!editingEmbarcacion) return;

    try {
      const response = await axios.put(`/api/embarcaciones/${editingEmbarcacion.id}`, embarcacion);
      setEmbarcaciones(embarcaciones.map(e => e.id === editingEmbarcacion.id ? response.data : e));
      setEditingEmbarcacion(null);
    } catch (error) {
      console.error('Error updating embarcacion:', error);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await axios.delete(`/api/embarcaciones/${id}`);
      setEmbarcaciones(embarcaciones.filter(e => e.id !== id));
    } catch (error) {
      console.error('Error deleting embarcacion:', error);
    }
  };

  return (
    <div>
      <h1>Gestión de Embarcaciones</h1>
      <EmbarcacionForm
        onSubmit={editingEmbarcacion ? handleUpdate : handleCreate}
        initialData={editingEmbarcacion || undefined}
        onCancel={() => setEditingEmbarcacion(null)}
      />
      <EmbarcacionTable
        embarcaciones={embarcaciones}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
    </div>
  );
};

export default App;
