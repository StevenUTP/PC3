package com.example.chancay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChancayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChancayApplication.class, args);
	}

}
